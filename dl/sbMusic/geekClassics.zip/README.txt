Place/copy into C:/Program Files(x86)/Steam/SteamApps/common/Starbound/assets/user

or your similar directory.